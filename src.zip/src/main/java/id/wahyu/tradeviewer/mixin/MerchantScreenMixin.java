package id.wahyu.tradeviewer.mixin;

import id.wahyu.tradeviewer.WahyuTradeViewer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.MerchantScreen;
import net.minecraft.screen.MerchantScreenHandler;
import net.minecraft.village.TradeOffer;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MerchantScreen.class)
public abstract class MerchantScreenMixin {
    @Shadow @Final protected MerchantScreenHandler handler;

    @Inject(method = "render", at = @At("TAIL"))
    private void wahyuTradeViewer$renderTradeList(DrawContext context, int mouseX, int mouseY,
                                                   float delta, CallbackInfo ci) {
        if (!WahyuTradeViewer.panelEnabled || handler == null) return;

        var offers = handler.getRecipes();
        int panelWidth = 172;
        int panelX = Math.max(4, context.getScaledWindowWidth() - panelWidth - 6);
        int panelY = 8;
        int visible = Math.min(offers.size(), 11);
        int panelHeight = 24 + visible * 18;

        context.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xD9141720);
        context.fill(panelX, panelY, panelX + panelWidth, panelY + 1, 0xFF8CA6FF);
        context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                Text.literal("Wahyu Trade Viewer"), panelX + 6, panelY + 5, 0xFFFFFFFF, false);

        if (offers.isEmpty()) {
            context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                    Text.literal("Belum ada offer dikirim"), panelX + 6, panelY + 18, 0xFFB8C0D0, false);
            return;
        }

        for (int i = 0; i < visible; i++) {
            TradeOffer offer = offers.get(i);
            ItemStack first = offer.getDisplayedFirstBuyItem();
            ItemStack second = offer.getDisplayedSecondBuyItem();
            ItemStack result = offer.getSellItem();
            String left = compact(first);
            if (!second.isEmpty()) left += " + " + compact(second);
            String line = (i + 1) + ". " + left + " → " + compact(result);
            int y = panelY + 20 + i * 18;
            int color = offer.isDisabled() ? 0xFF777D89 : 0xFFE6EAF2;
            context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                    Text.literal(line), panelX + 6, y, color, false);
        }

        if (offers.size() > visible) {
            context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                    Text.literal("+ " + (offers.size() - visible) + " trade lainnya"),
                    panelX + 6, panelY + 22 + visible * 18, 0xFFB8C0D0, false);
        }
    }

    private static String compact(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "-";
        String name = stack.getName().getString();
        if (stack.getCount() > 1) name = stack.getCount() + "x " + name;
        return name.length() > 20 ? name.substring(0, 19) + "…" : name;
    }
}
